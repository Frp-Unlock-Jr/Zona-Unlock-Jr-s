import React from 'react';
import { Monitor, Smartphone, Wrench, Unlock } from 'lucide-react';

export const COMPANY_NAME = "Frp Unlock Jr";
export const COMPANY_TAGLINE = "Reparacion y Mantenimiento de Equipos Moviles y Computo";
export const TELEGRAM_LINK = "https://t.me/+ISqNImJO30s4OTIx";
export const YOUTUBE_LINK = "https://www.youtube.com/@junior_unlock_46";

// REPLACE THIS URL with the actual URL of your uploaded banner image
export const BANNER_SRC = "https://placehold.co/1920x300/020617/00f3ff.png?text=FRP+UNLOCK+JR";

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: React.ElementType;
}

export const SERVICES: ServiceItem[] = [
  {
    id: 'pc-repair',
    title: 'Reparación de PC',
    description: 'Mantenimiento y Reparacion de Equipos de computo y celulares.',
    icon: Monitor,
  },
  {
    id: 'remote-support',
    title: 'Soporte Remoto',
    description: 'Asistencia técnica a distancia para resolver problemas de Bloqueo de tu Celular.',
    icon: Unlock,
  },
];

export interface TestimonialItem {
  id: string;
  name: string;
  image: string;
  text: string;
  rating: number;
}

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: '1',
    name: 'Carlos Mendez',
    image: 'https://images.unsplash.com/photo-1599566150163-29194dcaad36?q=80&w=200&auto=format&fit=crop',
    text: 'Excelente servicio, desbloquearon mi celular en minutos. Muy recomendado para cualquiera que necesite rapidez.',
    rating: 5
  },
  {
    id: '2',
    name: 'Ana García',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop',
    text: 'Tenía problemas con mi cuenta Google y lo solucionaron rápido y seguro. La atención fue muy amable.',
    rating: 5
  },
  {
    id: '3',
    name: 'Roberto Diaz',
    image: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?q=80&w=200&auto=format&fit=crop',
    text: 'Gran atención al cliente, me explicaron todo el proceso. 100% confiable y profesional.',
    rating: 5
  }
];

export const NAV_LINKS = [
  { label: 'Inicio', href: '#' },
  { label: 'Servicios', href: '#servicios' },
  { label: 'Opiniones', href: '#opiniones' },
  { label: 'Contacto', href: '#contacto' },
];