import React from 'react';
import { Star, Quote } from 'lucide-react';
import { TESTIMONIALS } from '../constants';

export const Testimonials: React.FC = () => {
  return (
    <section id="opiniones" className="py-24 bg-slate-900 relative overflow-hidden">
       {/* Background accents */}
       <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-slate-700 to-transparent"></div>
       <div className="absolute -left-20 top-1/2 w-64 h-64 bg-neon-cyan/5 rounded-full blur-[100px] pointer-events-none"></div>
       
       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
         <div className="text-center mb-16">
            <span className="text-neon-cyan font-bold tracking-widest uppercase text-xs border border-neon-cyan/30 px-3 py-1 rounded">Testimonios</span>
            <h2 className="mt-4 text-3xl md:text-5xl font-bold text-white mb-4">
              Clientes <span className="text-neon-cyan">Satisfechos</span>
            </h2>
            <div className="w-24 h-1 bg-neon-cyan mx-auto rounded-full shadow-[0_0_10px_#00f3ff]"></div>
         </div>

         <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
           {TESTIMONIALS.map((item) => (
             <div key={item.id} className="bg-slate-950 p-8 rounded-2xl border border-slate-800 relative hover:-translate-y-2 transition-transform duration-300 shadow-lg hover:shadow-neon-cyan/10 group">
               <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-neon-cyan to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
               <Quote className="absolute top-8 right-8 text-slate-800 w-10 h-10 group-hover:text-neon-cyan/20 transition-colors" />
               
               <div className="flex items-center gap-4 mb-6">
                 <img 
                   src={item.image} 
                   alt={item.name} 
                   className="w-14 h-14 rounded-full border-2 border-slate-700 group-hover:border-neon-cyan object-cover transition-colors"
                 />
                 <div>
                   <h4 className="text-white font-bold text-lg">{item.name}</h4>
                   <div className="flex text-yellow-500 mt-1 gap-0.5">
                     {[...Array(item.rating)].map((_, i) => (
                       <Star key={i} size={16} fill="currentColor" strokeWidth={0} />
                     ))}
                   </div>
                 </div>
               </div>
               
               <p className="text-slate-400 italic relative z-10 leading-relaxed group-hover:text-slate-300 transition-colors">
                 "{item.text}"
               </p>
             </div>
           ))}
         </div>
       </div>
    </section>
  );
};