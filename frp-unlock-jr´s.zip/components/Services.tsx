import React from 'react';
import { SERVICES } from '../constants';

export const Services: React.FC = () => {
  return (
    <section id="servicios" className="py-24 bg-slate-950 relative">
        {/* Glow Effects */}
        <div className="absolute top-1/4 left-0 w-64 h-64 bg-neon-purple/20 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-1/4 right-0 w-64 h-64 bg-neon-cyan/20 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <span className="text-neon-pink font-bold tracking-widest uppercase text-xs border border-neon-pink/30 px-3 py-1 rounded">Servicios Especializados</span>
          <h2 className="mt-4 text-4xl font-bold text-white sm:text-5xl tracking-tight">
            Nuestros <span className="text-neon-cyan">Servicios</span>
          </h2>
          <div className="w-32 h-1 bg-gradient-to-r from-neon-pink to-neon-cyan mx-auto mt-6 rounded-full shadow-[0_0_10px_#00f3ff]"></div>
        </div>

        <div className="flex flex-wrap justify-center gap-8">
          {SERVICES.map((service) => {
            const Icon = service.icon;
            return (
              <div 
                key={service.id} 
                className="group relative bg-slate-900/50 backdrop-blur-sm border border-slate-800 p-8 hover:border-neon-cyan/50 transition-all duration-500 hover:shadow-[0_0_30px_rgba(0,243,255,0.15)] w-full md:w-[calc(50%-1rem)] lg:w-[calc(33%-1rem)] max-w-sm rounded-2xl overflow-hidden"
              >
                {/* Hover Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-br from-neon-cyan/5 to-neon-purple/5 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                
                <div className="relative z-10">
                    <div className="flex items-center justify-center w-20 h-20 bg-slate-950 border border-slate-800 text-neon-cyan rounded-2xl mb-8 mx-auto group-hover:scale-110 group-hover:border-neon-cyan group-hover:shadow-[0_0_20px_rgba(0,243,255,0.4)] transition-all duration-300">
                    <Icon size={40} strokeWidth={1.5} className="drop-shadow-[0_0_5px_rgba(0,243,255,0.8)]" />
                    </div>
                    <h3 className="text-2xl font-bold text-white text-center mb-4 group-hover:text-neon-cyan transition-colors">
                    {service.title}
                    </h3>
                    <p className="text-slate-400 text-center leading-relaxed">
                    {service.description}
                    </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};