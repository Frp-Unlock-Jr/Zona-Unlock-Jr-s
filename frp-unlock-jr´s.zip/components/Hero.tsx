import React from 'react';
import { ArrowRight, Zap } from 'lucide-react';
import { COMPANY_TAGLINE } from '../constants';

export const Hero: React.FC = () => {
  return (
    <section className="relative bg-slate-950 overflow-hidden min-h-[80vh] flex items-center">
      {/* Background decoration */}
      <div className="absolute inset-0 z-0 opacity-40">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950 via-slate-900/80 to-slate-950 z-10"></div>
        {/* Abstract Neon Grid Background */}
        <div className="absolute inset-0" style={{ 
            backgroundImage: 'linear-gradient(rgba(0, 243, 255, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 243, 255, 0.05) 1px, transparent 1px)',
            backgroundSize: '40px 40px'
        }}></div>
        <img 
          src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=2070&auto=format&fit=crop" 
          alt="Cyberpunk Background" 
          className="w-full h-full object-cover mix-blend-overlay"
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20 w-full py-12">
        <div className="text-center max-w-4xl mx-auto">
          
          <div className="inline-flex items-center justify-center px-4 py-1.5 mb-8 border border-neon-cyan/30 rounded-full bg-neon-cyan/10 backdrop-blur-sm">
            <Zap className="w-4 h-4 text-neon-cyan mr-2 fill-neon-cyan" />
            <span className="text-neon-cyan text-xs font-bold tracking-[0.2em] uppercase">Expertos en Desbloqueos</span>
          </div>

          <h2 className="text-5xl md:text-7xl font-black text-white tracking-tight mb-6 leading-tight">
            Le damos <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-cyan via-white to-neon-pink drop-shadow-[0_0_10px_rgba(0,243,255,0.5)]">SOLUCIÓN</span> <br />
            a tus equipos
          </h2>
          
          <p className="mt-6 text-xl text-slate-300 mb-12 leading-relaxed font-light max-w-2xl mx-auto">
            {COMPANY_TAGLINE}
          </p>
          
          <div className="flex justify-center gap-6 flex-col sm:flex-row items-center">
            <a 
              href="#servicios" 
              className="w-full sm:w-auto px-8 py-4 border border-neon-cyan text-base font-bold rounded-none text-slate-950 bg-neon-cyan hover:bg-cyan-300 hover:shadow-neon-cyan transition-all duration-300 uppercase tracking-wider transform hover:-translate-y-1 skew-x-[-10deg]"
            >
              <div className="skew-x-[10deg]">Ver Servicios</div>
            </a>
            <a 
              href="#contacto" 
              className="w-full sm:w-auto px-8 py-4 border border-neon-pink text-base font-bold rounded-none text-neon-pink bg-transparent hover:bg-neon-pink/10 hover:shadow-neon-pink transition-all duration-300 uppercase tracking-wider transform hover:-translate-y-1 skew-x-[-10deg]"
            >
               <div className="skew-x-[10deg] flex items-center justify-center">
                  Contactar <ArrowRight className="ml-2 h-5 w-5" />
               </div>
            </a>
          </div>
        </div>
      </div>
      
      {/* Glowing divider at the bottom */}
      <div className="absolute bottom-0 w-full z-20 h-px bg-gradient-to-r from-transparent via-neon-cyan to-transparent opacity-50 shadow-[0_0_20px_#00f3ff]"></div>
    </section>
  );
};