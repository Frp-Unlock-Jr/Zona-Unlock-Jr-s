import React from 'react';
import { COMPANY_NAME, YOUTUBE_LINK } from '../constants';
import { Youtube, Zap } from 'lucide-react';

export const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-black text-slate-400 py-12 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          
          <div className="mb-6 md:mb-0 text-center md:text-left">
            <h3 className="text-white text-xl font-black mb-2 flex items-center gap-2 justify-center md:justify-start uppercase tracking-wider">
               <Zap className="text-neon-cyan h-5 w-5" />
               {COMPANY_NAME}
            </h3>
            <p className="text-sm text-slate-500">Soluciones de desbloqueo confiables.</p>
          </div>

          <div className="flex space-x-6 mb-6 md:mb-0">
            <a 
              href={YOUTUBE_LINK} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="text-slate-500 hover:text-red-600 hover:shadow-[0_0_15px_rgba(255,0,0,0.5)] transition-all transform hover:scale-110"
              aria-label="YouTube"
            >
              <Youtube size={32} />
            </a>
          </div>

          <div className="text-sm text-center md:text-right">
            <p className="text-slate-500">&copy; {currentYear} {COMPANY_NAME}.</p>
            <p className="text-xs mt-1 text-slate-700">Todos los derechos reservados.</p>
          </div>
          
        </div>
      </div>
    </footer>
  );
};