import React, { useState, useEffect } from 'react';
import { Menu, X, Smartphone } from 'lucide-react';
import { NAV_LINKS, COMPANY_NAME } from '../constants';

export const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  // Logic to split the title for styling (e.g., "Frp" bold, "Unlock Jr" thinner)
  const titleParts = COMPANY_NAME.split(' ');
  const titleMain = titleParts[0];
  const titleSub = titleParts.slice(1).join(' ');

  return (
    <header 
      className={`sticky top-0 z-40 transition-all duration-300 ${
        isScrolled 
          ? 'bg-slate-950/90 backdrop-blur-md shadow-[0_4px_30px_rgba(0,243,255,0.1)] py-2' 
          : 'bg-slate-950/50 backdrop-blur-sm py-4 border-b border-white/5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          
          {/* Logo Section - Restored Text/Icon */}
          <div className="flex items-center space-x-3 group cursor-pointer">
            <div className="relative">
              <div className="absolute inset-0 bg-neon-cyan blur-md opacity-20 group-hover:opacity-50 transition-opacity"></div>
              <div className="bg-slate-900 border border-slate-700 p-2 rounded-lg relative z-10 group-hover:border-neon-cyan transition-colors">
                <Smartphone className="h-6 w-6 text-neon-cyan" />
              </div>
            </div>
            <div className="text-white flex flex-col justify-center">
              <h1 className="font-black text-xl leading-none tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-300 group-hover:to-neon-cyan transition-all">
                {titleMain} <span className="text-neon-cyan">{titleSub}</span>
              </h1>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-bold text-slate-300 hover:text-neon-cyan transition-colors relative group uppercase tracking-widest"
              >
                {link.label}
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-neon-cyan shadow-[0_0_10px_#00f3ff] transition-all group-hover:w-full"></span>
              </a>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={toggleMenu}
              className="text-neon-cyan hover:text-white p-2 focus:outline-none transition-colors"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Dropdown */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-slate-900/95 border-t border-slate-800 absolute w-full left-0 top-full shadow-2xl backdrop-blur-xl">
          <div className="px-4 pt-4 pb-6 space-y-2">
            {NAV_LINKS.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="block px-3 py-3 rounded-md text-base font-bold text-slate-200 hover:text-neon-cyan hover:bg-slate-800/50 transition-all border-l-2 border-transparent hover:border-neon-cyan"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};