import React from 'react';
import { Send, Clock, MessageCircle } from 'lucide-react';
import { TELEGRAM_LINK } from '../constants';

export const Contact: React.FC = () => {
  return (
    <section id="contacto" className="py-24 bg-slate-950 border-t border-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="relative rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(188,19,254,0.15)] border border-slate-800">
            {/* Background Gradient */}
            <div className="absolute inset-0 bg-gradient-to-r from-slate-900 to-slate-950 z-0"></div>
            
            <div className="relative z-10 flex flex-col md:flex-row">
            
            {/* CTA Content */}
            <div className="p-10 md:p-16 md:w-2/3 text-left">
                <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                    ¿Equipo Bloqueado? <span className="text-neon-pink">Tenemos la llave.</span>
                </h2>
                <p className="text-slate-300 text-lg mb-10 max-w-xl">
                Contáctanos hoy mismo para agendar una visita técnica o soporte remoto. Estamos disponibles en nuestro canal de Telegram las 24hs.
                </p>
                
                <div className="flex flex-wrap gap-4">
                <a 
                    href={TELEGRAM_LINK}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center px-8 py-4 border border-transparent text-lg font-bold rounded-xl text-white bg-gradient-to-r from-blue-600 to-blue-500 hover:from-neon-cyan hover:to-blue-500 hover:shadow-neon-cyan transition-all duration-300 shadow-lg"
                >
                    <Send className="mr-3 h-6 w-6" />
                    Contactar por Telegram
                </a>
                </div>
            </div>

            {/* Info Side */}
            <div className="bg-slate-950/50 backdrop-blur md:w-1/3 flex flex-col justify-center p-10 space-y-8 border-t md:border-t-0 md:border-l border-slate-800">
                <div className="flex items-start space-x-4 group">
                    <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 group-hover:border-neon-lime group-hover:shadow-[0_0_10px_rgba(204,255,0,0.3)] transition-all">
                        <Clock className="h-6 w-6 text-neon-lime" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold text-lg">Horario</h4>
                        <p className="text-slate-400 text-sm mt-1">Lun - Vie: 9:00 - 18:30</p>
                        <p className="text-slate-400 text-sm">Sáb: 9:00 - 15:30</p>
                    </div>
                </div>

                <div className="flex items-start space-x-4 group">
                    <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 group-hover:border-neon-cyan group-hover:shadow-[0_0_10px_rgba(0,243,255,0.3)] transition-all">
                        <MessageCircle className="h-6 w-6 text-neon-cyan" />
                    </div>
                    <div>
                        <h4 className="text-white font-bold text-lg">Soporte</h4>
                        <p className="text-slate-400 text-sm mt-1">Atención rápida vía Telegram para desbloqueos.</p>
                    </div>
                </div>
            </div>

            </div>
        </div>
      </div>
    </section>
  );
};