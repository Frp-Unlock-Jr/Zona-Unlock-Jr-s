import React from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { BANNER_SRC, COMPANY_NAME } from './constants';

const App: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-slate-950">
      {/* Full Width Banner Section */}
      <div className="w-full bg-black border-b-2 border-neon-cyan/50 shadow-[0_0_20px_rgba(0,243,255,0.3)] relative z-50">
        <img 
          src={BANNER_SRC} 
          alt={COMPANY_NAME} 
          className="w-full h-auto object-contain md:object-cover max-h-[250px] mx-auto block"
        />
      </div>

      <Header />
      <main className="flex-grow">
        <Hero />
        <Services />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
};

export default App;